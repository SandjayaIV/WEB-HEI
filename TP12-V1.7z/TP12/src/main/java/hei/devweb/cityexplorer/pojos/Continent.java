package hei.devweb.cityexplorer.pojos;

public enum Continent {
    AFRICA, AMERICA, ASIA, EUROPE, OCEANIA;
}
