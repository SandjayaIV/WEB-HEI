let currentSelection = {};

let changeTab = function (continent) {
    currentSelection.continent = continent;
    currentSelection.country = undefined;
    currentSelection.city = undefined;

    listCountries(continent);
    let tabElements = document.querySelectorAll("#main-nav li.nav-item");
    for (const tabElement of tabElements) {
        if (tabElement.id === 'tab-' + continent.toLowerCase()) {
            tabElement.getElementsByTagName("a")[0].classList.add("active");
        } else {
            tabElement.getElementsByTagName("a")[0].classList.remove("active");
        }
    }
    document.getElementById("no-country-selected").hidden = false;
    document.getElementById("no-city-selected").hidden = true;
    document.getElementById("no-cities-in-country").hidden = true;
    document.getElementById("city-add-button").hidden = true;
    document.getElementById("cities-list").hidden = true;
    document.getElementById("city-details").hidden = true;
    document.getElementById("city-form").hidden = true;
    document.getElementById("country-add-button").onclick= updatedCountry;
};

let listCountries = function (continent) {
    let countriesRequest = new XMLHttpRequest();
    let url = "api/continents/"+continent+"/countries";
    countriesRequest.open("GET",url,true);
    countriesRequest.responseType = "json";
    countriesRequest.onload = function () {
        let countries = this.response;
        refreshCountriesList(countries);
    };
    countriesRequest.send();
    console.info("Méthode listCountries est implémentée");
};

let addCountry = function(country){
    let countryRequest = new XMLHttpRequest();
    let url = "api/continents/"+currentSelection.continent+"/countries/";

    countryRequest.open("POST",url,true);
    countryRequest.onload = function () {
        let newCountry = this.response;
        document.getElementById("countries-list").appendChild(createCountryLink(newCountry));
    };
    countryRequest.setRequestHeader("content-type", "application/x-www-form-urlencoded");
    countryRequest.send("codeCountry="+country.codeCountry+"&nameCountry="+country.nameCountry);

};
let updatedCountry = function(){
    let country = {
        codeCountry: document.getElementById('country-code-input').value,
        nameCountry: document.getElementById('country-name-input').value
    };
    addCountry(country);
};

let selectCountry = function (country) {
    currentSelection.country = country.code;
    listCities(country.code);

    selectLink("countries-list", "country" + country.code);

    document.getElementById("no-country-selected").hidden = true;
    document.getElementById("no-city-selected").hidden = false;
    document.getElementById("no-cities-in-country").hidden = true;
    document.getElementById("city-add-button").hidden = false;
    document.getElementById("cities-list").hidden = true;
    document.getElementById("city-details").hidden = true;
    document.getElementById("city-form").hidden = true;
};

let listCities = function (countryCode) {
    let listCitiesRequest = new XMLHttpRequest();
    let url = "api/continents/"+currentSelection+"/countries/"+countryCode+"/cities";
    listCitiesRequest.open("GET",url,true);
    listCitiesRequest.onload = function(){
        let listCity = this.response;
        if(listCity.status === 200){
            document.getElementById("cities-list").hidden = false;
            refreshCitiesList(listCity);
        }
        else{
            document.getElementById("no-cities-in-country").hidden = true;
        }
    };
    listCitiesRequest.send();
    console.error("Méthode listCities non implémentée");
};

let getCityDetail = function (cityId) {
    currentSelection.city = cityId;
    selectLink("cities-list", "city" + cityId);


    let name = document.getElementById("city-name");
    let population = document.getElementById("city-population");
    console.error("Méthode getCityDetail non implémentée");
    document.getElementById("no-city-selected").hidden = true;
    document.getElementById("city-form").hidden = true;
    document.getElementById("city-details").hidden = false;


};


window.onload = function () {
    changeTab("EUROPE");
};